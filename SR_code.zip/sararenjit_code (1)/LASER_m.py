#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  9 11:36:50 2020
LASER based multiclass classification
@author: sara
"""
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import Dense, LSTM
from tensorflow.keras import Sequential
from tensorflow.keras.utils import to_categorical
from matplotlib import pyplot
from sklearn import preprocessing
from tensorflow.keras.callbacks import EarlyStopping

'''embedding script run on colab  to get embedding file'''
#!bash /content/LASER/tasks/embed/embed.sh input.ml ml mlembed 

import numpy as np
dim = 1024
X1 = np.fromfile("textembed12000", dtype=np.float32, count=-1)                                                                          
X1.resize(X1.shape[0] // dim, dim) 
print (X1) 

X2 = np.fromfile("hypembed12000", dtype=np.float32, count=-1)                                                                          
X2.resize(X2.shape[0] // dim, dim) 
print (X2)

import xlrd 
loc = ("data.xlsx") 
Yin =[]
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_name('Data') 
print(sheet.cell_value(0, 0) )
  
for i in range(1,sheet.nrows):
    Yin.append(sheet.cell_value(i,2))
    

prod = np.multiply(X1,X2) #dim=1024
diff = X1-X2
absdiff = np.abs(diff)  #dim=1024
concat = np.concatenate((np.array(X1),np.array(X2),prod,absdiff),axis=1)
X= concat

label_encoder = preprocessing.LabelEncoder()
output_Y = label_encoder.fit_transform(Yin)
Y=output_Y
Y = to_categorical(output_Y)


trainX = X[0:7000]
testX=X[7000:12000]
trainY=Y[0:7000]
testY=Y[7000:12000]

#Model Building
model = Sequential()
model.add(Dense(4096,activation='relu'))
model.add(Dense(512, activation='relu'))
model.add(Dense(384,activation='relu'))
model.add(Dense(3,activation = 'softmax'))
model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy'])
early_stopping = EarlyStopping(monitor='val_loss', mode ='min',verbose=1)
history =model.fit(trainX, trainY, validation_split=0.2, epochs=100,callbacks=[early_stopping])
trainscore = model.evaluate(trainX,trainY)
testscore =model.evaluate(testX,testY)
model.summary()

print ("Final result")
pyplot.plot(history.history['acc'],label='train')    
pyplot.plot(history.history['val_acc'], label='val')
pyplot.ylabel('accuracy')
pyplot.xlabel('epochs')
pyplot.legend()
pyplot.show()

pyplot.plot(history.history['loss'],label='train')    
pyplot.plot(history.history['val_loss'], label='val')
#pyplot.title('Training-Val accuracy')
pyplot.ylabel('loss')
pyplot.xlabel('epochs')
pyplot.legend()
pyplot.show()

y_pred = model.predict_classes(testX)
y_prob = model.predict(testX)
########################################################
y_test_output_Y_onehot = np.argmax(testY, axis=1)

from sklearn.metrics import classification_report,accuracy_score
target_names = ['contradiction','entailment','neutral']
print(classification_report(y_test_output_Y_onehot, y_pred, target_names=target_names))
print (accuracy_score(y_test_output_Y_onehot, y_pred))

from sklearn.metrics import matthews_corrcoef
matthews_corrcoef(y_test_output_Y_onehot, y_pred)

from sklearn.metrics import log_loss
log_loss(y_test_output_Y_onehot, y_prob)


from sklearn.metrics import roc_curve, auc
fpr = dict()
tpr = dict()
roc_auc = dict()
for i in range(3):
    fpr[i], tpr[i], _ = roc_curve(testY[:,i], y_prob[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])
    
    
for i in range(3):
    pyplot.figure()
    pyplot.plot(fpr[i], tpr[i], label='ROC curve (area = %0.2f)' % roc_auc[i] )
    pyplot.plot([0, 1], [0, 1], 'k--')
    pyplot.xlim([0.0, 1.0])
    pyplot.ylim([0.0, 1.05])
    pyplot.xlabel('False Positive Rate')
    pyplot.ylabel('True Positive Rate')
    pyplot.title('Receiver operating characteristic:'+target_names[i])
    pyplot.legend(loc="lower right")
    pyplot.show()    


pyplot.figure()
pyplot.plot(fpr[0], tpr[0], label='ROC curve (area = %0.2f)Contradiction' % roc_auc[0], color='red')
pyplot.plot(fpr[1], tpr[1], label='ROC curve (area = %0.2f)Entailment' % roc_auc[1] , color='blue' )
pyplot.plot(fpr[2], tpr[2], label='ROC curve (area = %0.2f)Neutral' % roc_auc[2] , color='green' )
pyplot.plot([0, 1], [0, 1], 'k--')
pyplot.xlim([0.0, 1.0])
pyplot.ylim([0.0, 1.05])
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
#pyplot.title('Receiver operating characteristic:')

pyplot.legend(loc="lower right")
pyplot.show()    


