#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 10 07:25:37 2021
Adding attention on top of LASER
@author: hp
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  9 11:36:50 2020
LASER based multiclass classification
"""
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import Dense, LSTM,  Input, Flatten, Multiply,Activation,RepeatVector,Permute, Lambda
from tensorflow.keras.models import Model
from tensorflow.keras import Sequential
from tensorflow.keras.utils import to_categorical
from matplotlib import pyplot
from sklearn import preprocessing
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.decomposition import PCA
from keras.optimizers import Adam
'''embedding script run on colab  to get embedding file'''
#!bash /content/LASER/tasks/embed/embed.sh input.ml ml mlembed 


from keras.layers import Layer
import keras.backend as K
# class attention(Layer):
#     def __init__(self,**kwargs):
#         super(attention,self).__init__(**kwargs)

#     def build(self,input_shape):
#         self.W=self.add_weight(name="att_weight",shape=(input_shape[-1],1),initializer="normal")
#         self.b=self.add_weight(name="att_bias",shape=(input_shape[1],1),initializer="zeros")        
#         super(attention, self).build(input_shape)

#     def call(self,x):
#         print("bias shape")
#         print(self.b.shape)
#         print("weight shape")
#         s = K.dot(x,self.W)
#         print(s.shape)
#         et=K.squeeze(K.tanh(K.dot(x,self.W)+self.b),axis=-1)
#         at=K.softmax(et)
#         at=K.expand_dims(at,axis=-1)
#         output=x*at
#         return K.sum(output,axis=1)

#     def compute_output_shape(self,input_shape):
#         return (input_shape[0],input_shape[-1])

#     def get_config(self):
#         return super(attention,self).get_config()






import numpy as np
dim = 1024
X1 = np.fromfile("textembed12000", dtype=np.float32, count=-1)                                                                          
X1.resize(X1.shape[0] // dim, dim) 
print (X1) 

X2 = np.fromfile("hypembed12000", dtype=np.float32, count=-1)                                                                          
X2.resize(X2.shape[0] // dim, dim) 
print (X2)


def reduce_dimensions_pca(vectors, dimensions=500):
    reduced_vectors = PCA(n_components=dimensions).fit_transform(vectors)
    return reduced_vectors

x1_rd = reduce_dimensions_pca(X1)
x2_rd = reduce_dimensions_pca(X2)

#X1 = x1_rd
#X2 = x2_rd


import xlrd 
loc = ("inputfile") 
Yin =[]
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_name('sheetname') 
print(sheet.cell_value(0, 0) )
  
for i in range(1,sheet.nrows):
    Yin.append(sheet.cell_value(i,2))
    

prod = np.multiply(X1,X2) #dim=1024
diff = X1-X2
absdiff = np.abs(diff)  #dim=1024
concat = np.concatenate((np.array(X1),np.array(X2),prod,absdiff),axis=1)
X= concat

label_encoder = preprocessing.LabelEncoder()
output_Y = label_encoder.fit_transform(Yin)
Y=output_Y
Y = to_categorical(output_Y)


trainX = X[0:7000]
testX=X[7000:12000]
trainY=Y[0:7000]
testY=Y[7000:12000]
units=16
units1 = 256

#Model Building
#inputs = Input(shape=(4096), dtype='float32')
inputs= Input(shape=(4096), dtype='float32')
x1= Dense(4096,activation='relu')(inputs)




# #attention
# attention1=Dense(1, activation='tanh')(x1)
# attention1=Flatten()(attention1)
# attention1=Activation('softmax')(attention1)
# attention1=RepeatVector(units1)(attention1)
# attention1=Permute((2, 1))(attention1)


# sent_representation1 = Multiply()([x1, attention1])
# sent_representation1 = Lambda(lambda xin: K.sum(xin, axis=-2), output_shape=(units1*2,))(sent_representation1)

x2= Dense(512, activation='relu')(inputs)



x3= Dense(384,activation='relu')(x2)
x4= Dense(32,activation='relu')(x3)
x5= Dense(16,activation='relu')(x4)


# # #attention: Additive attention
attention=Dense(1, activation='tanh')(x5)
attention=Flatten()(attention)
attention=Activation('softmax')(attention)
attention=RepeatVector(units)(attention)
attention=Permute((2, 1))(attention)


sent_representation = Multiply()([x5, attention])
sent_representation = Lambda(lambda xin: K.sum(xin, axis=-2), output_shape=(units*2,))(sent_representation)



#x4 = Flatten()(x4)
#x5= attention()(x4)
#x6 = Multiply()([x4, x5])
#x6 = Flatten()(x5)


x7= Dense(3,activation = 'softmax')(sent_representation)


model = Model(inputs=inputs,outputs=x7)

model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy'])
early_stopping = EarlyStopping(monitor='val_loss',patience=3)# mode ='min',verbose=1)

model.summary()
history =model.fit(trainX, trainY, validation_split=0.2, epochs=100, verbose=1,callbacks=[early_stopping])
trainscore = model.evaluate(trainX,trainY)
testscore =model.evaluate(testX,testY)


print ("Final result")
pyplot.plot(history.history['accuracy'],label='train')    
pyplot.plot(history.history['val_accuracy'], label='val')
pyplot.ylabel('accuracy')
pyplot.xlabel('epochs')
pyplot.legend()
pyplot.show()

pyplot.plot(history.history['loss'],label='train')    
pyplot.plot(history.history['val_loss'], label='val')
#pyplot.title('Training-Val accuracy')
pyplot.ylabel('loss')
pyplot.xlabel('epochs')
pyplot.legend()
pyplot.show()

#y_pred = model.predict_classes(testX)
y_prob = model.predict(testX)
y_pred= np.argmax(y_prob, axis=-1)
########################################################
y_test_output_Y_onehot = np.argmax(testY, axis=1)

from sklearn.metrics import classification_report,accuracy_score
target_names = ['contradiction','entailment','neutral']
print(classification_report(y_test_output_Y_onehot, y_pred, target_names=target_names))
print (accuracy_score(y_test_output_Y_onehot, y_pred))

from sklearn.metrics import matthews_corrcoef
matthews_corrcoef(y_test_output_Y_onehot, y_pred)

from sklearn.metrics import log_loss
log_loss(y_test_output_Y_onehot, y_prob)


from sklearn.metrics import roc_curve, auc
fpr = dict()
tpr = dict()
roc_auc = dict()
for i in range(3):
    fpr[i], tpr[i], _ = roc_curve(testY[:,i], y_prob[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])
    
    
for i in range(3):
    pyplot.figure()
    pyplot.plot(fpr[i], tpr[i], label='ROC curve (area = %0.2f)' % roc_auc[i] )
    pyplot.plot([0, 1], [0, 1], 'k--')
    pyplot.xlim([0.0, 1.0])
    pyplot.ylim([0.0, 1.05])
    pyplot.xlabel('False Positive Rate')
    pyplot.ylabel('True Positive Rate')
    pyplot.title('Receiver operating characteristic:'+target_names[i])
    pyplot.legend(loc="lower right")
    pyplot.show()    

roc_auc[2]=0.79
pyplot.figure()
pyplot.plot(fpr[0], tpr[0],'-', label='ROC curve (area = %0.2f)Contradiction' % roc_auc[0], color='orange')
pyplot.plot(fpr[1], tpr[1],'-.', label='ROC curve (area = %0.2f)Entailment' % roc_auc[1] , color='blue' )
pyplot.plot(fpr[2], tpr[2],'--', label='ROC curve (area = %0.2f)Neutral' % roc_auc[2] , color='deepskyblue' )
pyplot.plot([0, 1], [0, 1], 'k--')
pyplot.xlim([0.0, 1.0])
pyplot.ylim([0.0, 1.05])
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
#pyplot.title('Receiver operating characteristic:')

pyplot.legend(loc="lower right")
pyplot.savefig(fname='laserm',dpi=300, format='png')
pyplot.savefig(fname='lasermpdf',dpi=300, format='pdf')
pyplot.show()    

from sklearn.metrics import confusion_matrix
print (confusion_matrix(y_test_output_Y_onehot, y_pred,labels=[0,1,2]))


#-------------cosine similarity

from scipy import spatial
sim =[]
sim_rd =[]
for x1,x2 in zip(X1,X2):
    result = 1 - spatial.distance.cosine(x1,x2)
    sim.append(result)

for x1,x2 in zip(x1_rd,x2_rd):
    results = 1 - spatial.distance.cosine(x1,x2)
    sim_rd.append(results)
