#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 22 18:12:41 2020
Doc2Vec based 
@author: sara
"""

#Read from excel
import xlrd 

import gensim
from matplotlib import pyplot
from sklearn.preprocessing import LabelEncoder
from keras.models import Sequential
from keras.layers import Dense,LSTM,Input
import numpy as np
import tensorflow as tf
from keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.utils import to_categorical

  
loc = ("data.xlsx") 
inputA = []
inputB = []
inputC = []

wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_name('Data') 
print(sheet.cell_value(0, 0) )
  
for i in range(1,sheet.nrows):
    inputA.append(sheet.cell_value(i, 0)) 
    inputB.append(sheet.cell_value(i,1))
    inputC.append(sheet.cell_value(i,2))

textlines = inputA
hyplines = inputB
label_out = inputC
output_class = label_out


import gensim.models as g

model="d2v_12000.model"  #point to download pre-trained doc2vec model

#load model
d2vmodel = g.Doc2Vec.load(model)

input_X={}
input_Y={}
Xlist=[]
Ylist=[]


for i in range(len(textlines)):
    d2vmodel.random.seed(0)
    inferred_vector = d2vmodel.infer_vector(list(textlines[i].split()))
    Xlist.append(inferred_vector)
    input_X[i] = inferred_vector
 
for i in range(len(hyplines)):
    d2vmodel.random.seed(0)
    hinferred_vector = d2vmodel.infer_vector(list(hyplines[i].split()))
    Ylist.append(hinferred_vector)
    input_Y[i] = hinferred_vector


    
encoder = LabelEncoder()
encoder.fit(label_out)
encoded_Y = encoder.transform(label_out)
Y = to_categorical(encoded_Y)

X1 = np.stack(Xlist,axis=0)
X2 = np.stack(Ylist,axis=0)

prod = np.multiply(X1,X2) #dim=1024
diff = X1-X2
absdiff = np.abs(diff)  #dim=1024
concat = np.concatenate((np.array(X1),np.array(X2),prod,absdiff),axis=1)
X= concat


trainX = X[0:7000]
trainY = Y[0:7000]
testX = X[7000:12000]
testY = Y[7000:12000]

model = Sequential()
model.add(Dense(400, activation='relu'))
model.add(Dense(200,activation='relu'))
model.add(Dense(3,activation = 'softmax'))
model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy'])
early_stopping = EarlyStopping(monitor='val_loss',mode ='min',verbose=1) #
history =model.fit(trainX, trainY, validation_split=0.2, epochs=1000,callbacks=[early_stopping])
trainscore = model.evaluate(trainX,trainY)
testscore =model.evaluate(testX,testY)
model.summary()

print ("Final result")
pyplot.plot(history.history['acc'],label='train')    
pyplot.plot(history.history['val_acc'], label='val')
pyplot.ylabel('accuracy')
pyplot.xlabel('epochs')
pyplot.legend()
pyplot.show()

pyplot.plot(history.history['loss'],label='train')    
pyplot.plot(history.history['val_loss'], label='val')
pyplot.ylabel('loss')
pyplot.xlabel('epochs')
pyplot.legend()
pyplot.show()

y_pred = model.predict_classes(testX)
y_prob = model.predict(testX)

#Evaluation metrics
y_test_output_Y_onehot = np.argmax(testY, axis=1)
#y_test_output_Y_onehot = Y_test
from sklearn.metrics import classification_report,accuracy_score
target_names = ['contradiction','entailment','neutral']
print(classification_report(y_test_output_Y_onehot, y_pred, target_names=target_names))
print (accuracy_score(y_test_output_Y_onehot, y_pred))

from sklearn.metrics import matthews_corrcoef
matthews_corrcoef(y_test_output_Y_onehot, y_pred)

from sklearn.metrics import log_loss
log_loss(y_test_output_Y_onehot, y_prob)


from sklearn.metrics import roc_curve, auc
fpr = dict()
tpr = dict()
roc_auc = dict()
for i in range(3):
    fpr[i], tpr[i], _ = roc_curve(testY[:,i], y_prob[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])
    
    
for i in range(3):
    pyplot.figure()
    pyplot.plot(fpr[i], tpr[i], label='ROC curve (area = %0.2f)' % roc_auc[i] )
    pyplot.plot([0, 1], [0, 1], 'k--')
    pyplot.xlim([0.0, 1.0])
    pyplot.ylim([0.0, 1.05])
    pyplot.xlabel('False Positive Rate')
    pyplot.ylabel('True Positive Rate')
    #pyplot.title('Receiver operating characteristic:'+target_names[i])
    pyplot.legend(loc="lower right")
    pyplot.show()    


pyplot.figure()
pyplot.plot(fpr[0], tpr[0], label='ROC curve (area = %0.2f)Contradiction' % roc_auc[0], color='red')
pyplot.plot(fpr[1], tpr[1], label='ROC curve (area = %0.2f)Entailment' % roc_auc[1] , color='blue' )
pyplot.plot(fpr[2], tpr[2], label='ROC curve (area = %0.2f)Neutral' % roc_auc[2] , color='green' )
pyplot.plot([0, 1], [0, 1], 'k--')
pyplot.xlim([0.0, 1.0])
pyplot.ylim([0.0, 1.05])
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
#pyplot.title('Receiver operating characteristic:')

pyplot.legend(loc="lower right")
pyplot.show()    



