#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  5 16:02:11 2021
Siamese lSTM with LASER embeddings
@author: hp
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Siamese LSTM 
@author: hp
"""

from keras.preprocessing.text import Tokenizer
from keras.utils import pad_sequences
#from keras.preprocessing.sequence import pad_sequences
from sklearn.decomposition import PCA
from keras.layers import Dense, Input, LSTM, Dropout, Bidirectional,Flatten
from tensorflow.keras.layers import BatchNormalization

#from keras.layers.normalization import BatchNormalization

from gensim.models import Word2Vec
from keras.models import load_model
import gc
import numpy as np
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.utils import to_categorical
from sklearn import preprocessing
from operator import itemgetter
from sklearn.model_selection import train_test_split
from keras.layers import concatenate

#from keras.layers.merge import concatenate
from keras.models import load_model,Model

from keras.callbacks import TensorBoard,EarlyStopping, ModelCheckpoint
from operator import itemgetter

import time,os


#initialized required parameters for LSTM network...
EMBEDDING_DIM = 100
MAX_SEQUENCE_LENGTH = 100
VALIDATION_SPLIT = 0.2
RATE_DROP_LSTM = 0.17
RATE_DROP_DENSE = 0.25
NUMBER_LSTM = 512
NUMBER_DENSE_UNITS = 100
ACTIVATION_FUNCTION = 'relu'


#inputComb = inputcomb

def train_model(t_train, h_train, Y_train, t_val, h_val, Y_val):
    model_save_directory='logpath'

   
    # Creating LSTM Encoder
    print ("bi")
    lstm_layer = Bidirectional(LSTM(NUMBER_LSTM, dropout=RATE_DROP_LSTM, recurrent_dropout=RATE_DROP_LSTM,return_sequences=True))
    print("seq1")

    # Creating LSTM Encoder layer for First Sentence
    sequence_1_input = Input(shape=(MAX_SEQUENCE_LENGTH,1), dtype='float32')
#        embedded_sequences_1 = embedding_layer(sequence_1_input)
    print("x1")
    x1 = lstm_layer(sequence_1_input)

    # Creating LSTM Encoder layer for Second Sentence
    sequence_2_input = Input(shape=(MAX_SEQUENCE_LENGTH,1), dtype='float32')
    #embedded_sequences_2 = embedding_layer(sequence_2_input)
    x2 = lstm_layer(sequence_2_input)

    # Creating leaks input
    #leaks_input = Input(shape=(leaks_train.shape[1],))
    #leaks_dense = Dense(self.number_dense_units/2, activation=self.activation_function)(leaks_input)

    # Merging two LSTM encodes vectors from sentences to
    # pass it to dense layer applying dropout and batch normalisation
    #con = concatenate([x1,x2])
    
    merged = concatenate([x1, x2])#, leaks_dense])
    merged = BatchNormalization()(merged)
    merged = Dropout(RATE_DROP_DENSE)(merged)
    merged = Dense(NUMBER_DENSE_UNITS, activation=ACTIVATION_FUNCTION)(merged)
    merged = BatchNormalization()(merged)
    merged = Dropout(RATE_DROP_DENSE)(merged)
    merged = Flatten()(merged)
    preds = Dense(3, activation='softmax')(merged)

    model = Model(inputs=[sequence_1_input, sequence_2_input], outputs=preds)  #leaks_input
    model.compile(loss='categorical_crossentropy', optimizer='nadam', metrics=['acc'])
    model.summary()

    early_stopping = EarlyStopping(monitor='val_loss', patience=5)

    STAMP = 'lstm_%d_%d_%.2f_%.2f' % (NUMBER_LSTM, NUMBER_DENSE_UNITS, RATE_DROP_LSTM, RATE_DROP_DENSE)

    checkpoint_dir = model_save_directory + 'checkpoints/' + str(int(time.time())) + '/'

    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)

    bst_model_path = checkpoint_dir + STAMP + '.h5'

    model_checkpoint = ModelCheckpoint(bst_model_path, save_best_only=True, save_weights_only=False)

    tensorboard = TensorBoard(log_dir=checkpoint_dir + "logs/{}".format(time.time()))

    model.fit([t_train, h_train], Y_train,
              validation_data=([t_val, h_val], Y_val),
              epochs=200, batch_size=64, shuffle=True,
              callbacks=[early_stopping, model_checkpoint, tensorboard])
    
    
    return bst_model_path





# Load the dataset for classification

import numpy as np
dim = 1024
X1 = np.fromfile("inputloc1", dtype=np.float32, count=-1)
X1.resize(X1.shape[0] // dim, dim) 
print (X1) 

X2 = np.fromfile("/inputloc2", dtype=np.float32, count=-1)
X2.resize(X2.shape[0] // dim, dim) 
print (X2)


def reduce_dimensions_pca(vectors, dimensions=100):
    reduced_vectors = PCA(n_components=dimensions).fit_transform(vectors)
    return reduced_vectors

x1_rd = reduce_dimensions_pca(X1)
x2_rd = reduce_dimensions_pca(X2)

X1 = x1_rd
X2 = x2_rd

import xlrd3
loc = ("inputfilepath")
Yin =[]
wb = xlrd3.open_workbook(loc)
sheet = wb.sheet_by_name('sheetname') 
print(sheet.cell_value(0, 0) )
  
for i in range(1,sheet.nrows):
    Yin.append(sheet.cell_value(i,2))
    

#prod = np.multiply(X1,X2) #dim=1024
#diff = X1-X2
#absdiff = np.abs(diff)  #dim=1024
#concat = np.concatenate((np.array(X1),np.array(X2),prod,absdiff),axis=1)
#X= concat

label_encoder = preprocessing.LabelEncoder()
output_Y = label_encoder.fit_transform(Yin)
Y=output_Y
Y = to_categorical(output_Y)

t_train = X1[0:7000]
h_train = X2[0:7000]
Y_train = Y[0:7000]


t_val = X1[6000:7000]
h_val = X2[6000:7000]
Y_val = Y[6000:7000]

t_test = X1[7000:12000]
h_test = X2[7000:12000]
Y_test = Y[7000:12000]

# Set more global constants
num_categories = 3

#tconverted_train = splitconvert(t_train)
#hconverted_train = splitconvert(h_train)
#
#tconverted_test = splitconvert(t_test)
#hconverted_test = splitconvert(h_test)
#
#thconverted_train = tconverted_train + hconverted_train
#thconverted_test = tconverted_test + hconverted_test


#Y=encoded_Y


#recognition_pair = [(x1, x2) for x1, x2 in zip(X1, X2)]
print("----------created questions pairs-----------")

#import numpy as np 
#
t_train = np.expand_dims(t_train, axis = -1)  
h_train = np.expand_dims(h_train,axis=-1)
t_val = np.expand_dims(t_val,axis=-1)
h_val = np.expand_dims(h_val,axis=-1)
  
#SiameneBiLSTM is a class for  Long short Term Memory networks
#siamese = Siamese_LSTM_network.SiameseLSTM(EMBEDDING_DIM ,MAX_SEQUENCE_LENGTH, NUMBER_LSTM, NUMBER_DENSE_UNITS, RATE_DROP_LSTM, RATE_DROP_DENSE, ACTIVATION_FUNCTION, VALIDATION_SPLIT)
model_path = train_model(t_train, h_train, Y_train, t_val, h_val, Y_val)
    
#load the train data in model...
model = load_model(model_path)
print("----------model trained-----------")

#TESTING

#thtest_pair = [(x1, x2) for x1, x2 in zip(tconverted_test, hconverted_test)]
#test_data_x1, test_data_x2, leaks_test = pre_processing.create_test_data(tokenizer,thtest_pair, MAX_SEQUENCE_LENGTH)
#predict the results
preds = list(model.predict([t_test, h_test], verbose=1).ravel())
print("----------predicted test results-----------")

#mapping results with input test data...
results = [(x, y, z) for (x, y), z in zip(thtest_pair, preds)]
print("----------mapping test results-----------")

results.sort(key=itemgetter(2), reverse=True)

evalresults = list(model.evaluate([t_test, h_test],Y_test, verbose=1))
