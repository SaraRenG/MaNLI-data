#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  9 11:36:50 2020
LASER based Binary classification
@author: sara
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import Dense, LSTM
from tensorflow.keras import Sequential
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping
from sklearn import preprocessing
from matplotlib import pyplot


'''embedding script run on colab  to get embedding file'''
#!bash /content/LASER/tasks/embed/embed.sh input.ml ml mlembed 

import numpy as np
dim = 1024
X1 = np.fromfile("textembed7989", dtype=np.float32, count=-1)                                                                          
X1.resize(X1.shape[0] // dim, dim) 
print (X1) 

X2 = np.fromfile("hypembed7989", dtype=np.float32, count=-1)                                                                          
X2.resize(X2.shape[0] // dim, dim) 
print (X2)

import xlrd 
loc = ("data.xlsx") 
Y =[]
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_name('Data') 
print(sheet.cell_value(0, 0) )
  
for i in range(1,sheet.nrows):
    Y.append(sheet.cell_value(i,2))
    
prod = np.multiply(X1,X2) 
diff = X1-X2
absdiff = np.abs(diff) 
concat = np.concatenate((np.array(X1),np.array(X2),prod,absdiff),axis=1)
X= concat

label_encoder = preprocessing.LabelEncoder()
output_Y = label_encoder.fit_transform(Y)
Y=output_Y

trainX = X[0:6391]
testX=X[6391:7989]

trainY=Y[0:6391]
testY=Y[6391:7989]
YtestY = to_categorical(testY,2)

#Model Building
model = Sequential()
model.add(Dense(4096,activation='relu'))
model.add(Dense(512, activation='relu'))
model.add(Dense(384,activation='relu'))
model.add(Dense(1,activation = 'sigmoid'))
model.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])
early_stopping = EarlyStopping(monitor='val_loss',mode ='min',verbose=1)
history = model.fit(trainX, trainY, validation_split=0.2, epochs=100,callbacks=[early_stopping])
trainscore = model.evaluate(trainX,trainY)
testscore =model.evaluate(testX,testY)


y_pred = model.predict_classes(testX)
y_prob = model.predict(testX)

y_test_output_Y_onehot = np.argmax(YtestY, axis=1)

#Evaluation
from sklearn.metrics import classification_report,accuracy_score
target_names = ['contradiction','entailment']
print(classification_report(y_test_output_Y_onehot, y_pred, target_names=target_names))
print (accuracy_score(testY, y_pred))

from sklearn.metrics import matthews_corrcoef
matthews_corrcoef(testY, y_pred)

from sklearn.metrics import log_loss
log_loss(testY, y_prob)

# Compute ROC curve and ROC area for each class
from sklearn.metrics import roc_curve, auc
fpr = dict()
tpr = dict()
roc_auc = dict()
fpr, tpr, _ = roc_curve(testY, y_prob)
roc_auc = auc(fpr, tpr)

pyplot.figure()
pyplot.plot(fpr, tpr, label='ROC curve (area = %0.2f)' % roc_auc, color='blue')
pyplot.plot([0, 1], [0, 1], 'k--')
pyplot.xlim([0.0, 1.0])
pyplot.ylim([0.0, 1.05])
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
#pyplot.title('ROC for NLI in Malayalam using LASER')

pyplot.legend(loc="lower right")
pyplot.show()  
