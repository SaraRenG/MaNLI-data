#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  5 22:09:32 2021

@author: hp
"""

from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing import sequence

from text_att_birnn import TextAttBiRNN
from sklearn.preprocessing import LabelEncoder
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

max_features = 5000
maxlen = 400
batch_size = 32
embedding_dims = 50
epochs = 10


def splitconvert(inputlist):
    elelist=[]
    for sentence in inputlist:
        if sentence not in ' ':
            sentence = sentence.strip('.\n').replace('.\t',' ')
            sentence = sentence.replace('.\t',' ')
            tokens = sentence
            tokens = sentence.split(" ")
            elelist.append(tokens)
    return elelist


import xlrd
loc = ("inputfilepath") 
inputA = []
inputB = []
inputC = []
inputcomb=[]
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_name('sheetname') 
print(sheet.cell_value(0, 0) )
  
for i in range(1,sheet.nrows):
    inputA.append(sheet.cell_value(i, 0)) 
    inputB.append(sheet.cell_value(i,1))
    inputcomb.append(sheet.cell_value(i,0)+ sheet.cell_value(i,1))    
    inputC.append(sheet.cell_value(i,2))

#textlines = inputA
#hyplines = inputB
label_out = inputC
output_class = label_out




train = inputcomb[0:6989]
test = inputcomb[0:6989]

encoder = LabelEncoder()
encoder.fit(label_out)
encoded_Y = encoder.transform(label_out)
Y= encoded_Y

y_train = Y[0:6989]
y_test = Y[6989:7989]


# Set more global constants
num_categories = 3



trainconverted = splitconvert(train)
testconverted = splitconvert(test)



tokenizer = Tokenizer() # nb_words=MAX_NB_WORDS
tokenizer.fit_on_texts(trainconverted + testconverted )
#sequence = tokenizer.texts_to_sequences(inputComb)
x_train = tokenizer.texts_to_sequences(trainconverted)
x_test = tokenizer.texts_to_sequences(testconverted)

# print('Loading data...')
# (x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=max_features)
# print(len(x_train), 'train sequences')
# print(len(x_test), 'test sequences')

print('Pad sequences (samples x time)...')
x_train = sequence.pad_sequences(x_train, maxlen=maxlen)
x_test = sequence.pad_sequences(x_test, maxlen=maxlen)
print('x_train shape:', x_train.shape)
print('x_test shape:', x_test.shape)

print('Build model...')
model = TextAttBiRNN(maxlen, max_features, embedding_dims)
model.compile('adam', 'binary_crossentropy', metrics=['accuracy'])

print('Train...')
early_stopping = EarlyStopping(monitor='val_accuracy', patience=3, mode='max')
model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=epochs,
          callbacks=[early_stopping],
          validation_data=(x_test, y_test))

print('Test...')
result = model.predict(x_test)
