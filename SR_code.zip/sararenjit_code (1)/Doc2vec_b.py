#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 22 19:26:56 2020
Doc2Vec based
@author: sara
"""

#Read from excel
import xlrd 

import gensim
from matplotlib import pyplot
from sklearn.preprocessing import LabelEncoder
from keras.models import Sequential
from keras.layers import Dense,LSTM,Input
import numpy as np
import tensorflow as tf
from keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.utils import to_categorical

  
loc = ("data.xlsx") 
inputA = []
inputB = []
inputC = []

wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_name('Data') 
print(sheet.cell_value(0, 0) )
  
for i in range(1,sheet.nrows):
    inputA.append(sheet.cell_value(i, 0)) 
    inputB.append(sheet.cell_value(i,1))
    inputC.append(sheet.cell_value(i,2))

textlines = inputA
hyplines = inputB
label_out = inputC
output_class = label_out


import gensim.models as g

model="d2v_12000.model"  #point to downloaded pre-trained doc2vec model

#load model
d2vmodel = g.Doc2Vec.load(model)


input_X={}
input_Y={}
Xlist=[]
Ylist=[]


for i in range(len(textlines)):
    d2vmodel.random.seed(0)
    inferred_vector = d2vmodel.infer_vector(list(textlines[i].split()))
    Xlist.append(inferred_vector)
    input_X[i] = inferred_vector
 
for i in range(len(hyplines)):
    d2vmodel.random.seed(0)
    hinferred_vector = d2vmodel.infer_vector(list(hyplines[i].split()))
    Ylist.append(hinferred_vector)
    input_Y[i] = hinferred_vector

   
encoder = LabelEncoder()
encoder.fit(label_out)
encoded_Y = encoder.transform(label_out)
Y=encoded_Y

X1 = np.stack(Xlist,axis=0)
X2 = np.stack(Ylist,axis=0)

prod = np.multiply(X1,X2) #dim=1024
diff = X1-X2
absdiff = np.abs(diff)  #dim=1024
concat = np.concatenate((np.array(X1),np.array(X2),prod,absdiff),axis=1)
X= concat


trainX = X[0:6391]
trainY = Y[0:6391]
testX = X[6391:7989]
testY = Y[6391:7989]
YtestY = to_categorical(testY,2)

model = Sequential()
model.add(Dense(400, activation='relu'))
model.add(Dense(200,activation='relu'))
model.add(Dense(1,activation = 'sigmoid'))
model.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])
early_stopping = EarlyStopping(monitor='val_loss',mode ='min',verbose=1)
history = model.fit(trainX, trainY, validation_split=0.2, epochs=100,callbacks=[early_stopping])
trainscore = model.evaluate(trainX,trainY)
testscore =model.evaluate(testX,testY)


y_pred = model.predict_classes(testX)
y_prob = model.predict(testX)

y_test_output_Y_onehot = np.argmax(YtestY, axis=1)

#Evaluation
from sklearn.metrics import classification_report,accuracy_score
target_names = ['contradiction','entailment']
print(classification_report(y_test_output_Y_onehot, y_pred, target_names=target_names))
print (accuracy_score(testY, y_pred))

from sklearn.metrics import matthews_corrcoef
matthews_corrcoef(testY, y_pred)

from sklearn.metrics import log_loss
log_loss(testY, y_prob)

from sklearn.metrics import roc_curve, auc
fpr = dict()
tpr = dict()
roc_auc = dict()
fpr, tpr, _ = roc_curve(testY, y_prob)
roc_auc = auc(fpr, tpr)

pyplot.figure()
pyplot.plot(fpr, tpr, label='ROC curve (area = %0.2f)' % roc_auc, color='blue')
pyplot.plot([0, 1], [0, 1], 'k--')
pyplot.xlim([0.0, 1.0])
pyplot.ylim([0.0, 1.05])
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
pyplot.legend(loc="lower right")
pyplot.show()  
