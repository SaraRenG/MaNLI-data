#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 11:54:33 2020
@author: hp
"""
import nltk
import codecs
import numpy as np
from nltk.util import ngrams
from sklearn.model_selection import train_test_split
#from nltk.translate.nist_score 
#from nltk.translate.meteor_score import
from nltk.translate.bleu_score import sentence_bleu
#import indicstemmer.libindic.stemmer.Malayalam_modified as mm
import word2vec as wv
import math
import gensim
from scipy.spatial import distance
#import POSTagger as Tagger

#from libindic.stemmer import Stemmer
import requests
from indicstemmer.libindic.stemmer import Malayalam_modified as mm
from sklearn import preprocessing
from keras.utils import to_categorical
from sklearn.metrics import precision_score,recall_score,f1_score
from nltk.util import skipgrams
import textdistance
from sklearn.metrics.pairwise import cosine_similarity
'''Machine Learning imports'''

tokenize = lambda doc: doc.lower().split(" ")

def term_frequency(term, tokenized_document):
    return tokenized_document.count(term)
 
def sublinear_term_frequency(term, tokenized_document):
    count = tokenized_document.count(term)
    if count == 0:
        return 0
    return 1 + math.log(count)
 
def augmented_term_frequency(term, tokenized_document):
    max_count = max([term_frequency(t, tokenized_document) for t in tokenized_document])
    return (0.5 + ((0.5 * term_frequency(term, tokenized_document))/max_count))
 
def inverse_document_frequencies(tokenized_documents):
    idf_values = {}
    all_tokens_set = set([item for sublist in tokenized_documents for item in sublist])
    for tkn in all_tokens_set:
        contains_token = map(lambda doc: tkn in doc, tokenized_documents)
        idf_values[tkn] = 1 + math.log(len(tokenized_documents)/(sum(contains_token)))
    return idf_values
 
def tfidf(documents):
    tokenized_documents = [tokenize(d) for d in documents]
    idf = inverse_document_frequencies(tokenized_documents)
    tfidf_documents = []
    for document in tokenized_documents:
        doc_tfidf = []
        for term in idf.keys():
            tf = augmented_term_frequency(term, document)
            doc_tfidf.append(tf * idf[term])
        tfidf_documents.append(doc_tfidf)
    return tfidf_documents


#def cosine_similarity1(vector1, vector2):
#    dot_product = sum(p*q for p,q in zip(vector1, vector2))
#    magnitude = math.sqrt(sum([val**2 for val in vector1])) * math.sqrt(sum([val**2 for val in vector2]))
#    if not magnitude:
#        return 0
#    return dot_product/magnitude





def lcs(X, Y): 
    # find the length of the strings 
    m = len(X) 
    n = len(Y)
    print("xlen"+str(m))
    print("ylen"+str(n))
  
    # declaring the array for storing the dp values 
    L = [[None]*(n + 1) for i in range(m + 1)] 
  
    """Following steps build L[m + 1][n + 1] in bottom up fashion 
    Note: L[i][j] contains length of LCS of X[0..i-1] 
    and Y[0..j-1]"""
    for i in range(m + 1): 
        for j in range(n + 1): 
            if i == 0 or j == 0 : 
                L[i][j] = 0
            elif X[i-1] == Y[j-1]:
                print(X[i-1])
                print(Y[j-1])
                L[i][j] = L[i-1][j-1]+1
            else: 
                L[i][j] = max(L[i-1][j], L[i][j-1]) 
  
    # L[m][n] contains the length of LCS of X[0..n-1] & Y[0..m-1] 
    return L[m][n] 
# end of function lcs 


loc = ("inputfilepath")
inputA = []
inputB = []
inputC = []

wb = xlrd3.open_workbook(loc)
sheet = wb.sheet_by_name('sheetname') 
print(sheet.cell_value(0, 0) )
  
for i in range(0,sheet.nrows):
    print (i)
    print (sheet.cell_value(i,0))
    inputA.append(sheet.cell_value(i, 0))
    print (sheet.cell_value(i,1))
    inputB.append(sheet.cell_value(i,1))
    print(sheet.cell_value(i,2))
    inputC.append(sheet.cell_value(i,2))

textlines = inputA
hyplines = inputB
label_out = inputC
output_class = label_out

x = slice(0,12000)

textlines = textlines[x]
hyplines = hyplines[x]
output_class = output_class[x]

'''End'''

#output_class = word2vec.converttolist(label_out)
label_encoder = preprocessing.LabelEncoder()
output_Y = label_encoder.fit_transform(output_class)

textstemmedlist =[]
hypstemmedlist =[]
totalsimscore = []
scores ={}
scoresum = {}
predictedclass = {}

       
count =0

stemmer = mm.Malayalam_modified()
modelname = 'w2vmodel_12000'
wvmodel = gensim.models.Word2Vec.load(modelname)

f = codecs.open('features4class_3class.txt',mode='w')
for (eachtext, eachhyp,outclass) in zip(textlines, hyplines,output_class):
    print (eachtext)
    print (eachhyp)
    print(outclass)
    
    print (count)
    textstemmed=''
    hypstemmed=''
    tempscore=[]
    scoresavg=[]
    stemmedtext = stemmer.stem(text= eachtext)
    stemmedhyp = stemmer.stem(text = eachhyp)
    
    for word , output in stemmedtext.items():
        textstemmed += ' '+str(str(output['stem']))
    print("textstemmed:"+textstemmed)
    print(textstemmed)
    textstemmedlist.append(textstemmed)
    
    for word , output in stemmedhyp.items():
        hypstemmed += ' '+str(str(output['stem']))
    print("hypstemmed:"+hypstemmed)
    print(hypstemmed)
    hypstemmedlist.append(hypstemmed)
  
    
    #print ("Bigrams")
    bigrams_text = []
    
    bigrams_text.extend(list(ngrams(textstemmed.split(), 2)))
    print ("Bigrams_Text\n")
    print (bigrams_text)
    
    bigrams_hyp = []
    bigrams_hyp.extend(list(ngrams(hypstemmed.split(), 2)))
    print ("Bigrams_Hyp\n")
    print (bigrams_hyp)
    
    bgram_match =0
    skgram_match =0

    freq_dist_hyp = nltk.FreqDist(bigrams_hyp)
    prob_dist_hyp = nltk.MLEProbDist(freq_dist_hyp)
    number_of_bigrams = freq_dist_hyp.N()
    
    '''
    ======================Lexical Similarity===============================================
    '''
    
    '''1) *************WORD OVERLAP (WordNet based UNIGRAM Match) W. r. t Hypothesis***********************'''
    
    print ("UNIGRAM MATCH wrt hypothesis")
    wordoverlap =0
    tword_syn = 0
    for tword in textstemmed.split():
        if tword in hypstemmed.split():
            wordoverlap = wordoverlap+1
# #        else:
# #            #find tword synonym
# #            url = "http://malayalamwordnet.cusat.ac.in/restapi/json/synset/"+tword
# #            response = requests.request("GET", url)
# #            print (response)
# #            
# #            if tword_syn in hypstemmed:
# #                wordoverlap = wordoverlap+1 
    overlapscore_h = wordoverlap/ len(hypstemmed.split())
    print (overlapscore_h)
    
        
    tempscore.append(overlapscore_h)
    print (tempscore)
    
    '''2) *************WORD OVERLAP (WordNet based UNIGRAM Match) W. r. t Text***********************'''
    overlapscore_t = wordoverlap/ len(textstemmed.split())
    print (overlapscore_t)
    
        
    tempscore.append(overlapscore_t)
    print (tempscore)
    
#     '''3)***********************BIGRAM MATCH**********************************'''
    
    print("BIGRAM MATCH")
    # # 2)bigram match
    for bg in bigrams_text:
        if bg in bigrams_hyp:
            bgram_match = bgram_match +1
    
    bigram_match = bgram_match / number_of_bigrams
    print (bigram_match)
    
    # '''
    # if bigram_match > 0:
    #     print ("\nEntailment")
    # else:
    #     print ("\n NonEntailment")        
    # '''
    
    tempscore.append(float(bigram_match))
    print (tempscore)
    
# #    
#     '''4)*************************LONGEST COMMON SUBSEQUENCE MATCH***************************'''
    
    print ("LONGEST COMMON SUBSEQUENCE")
    # # 3) Longest Common Subsequence
    lcsval = (lcs(textstemmed,hypstemmed))
    print(lcsval)
    lcsmatch = lcsval/len(hypstemmed)
    tempscore.append(float(lcsmatch))
    print (tempscore)
    print ("\n LCSmatch:")
    print (lcsmatch)
    
    scores[count] =tempscore
#    scoresavg.append(np.mean(scores[count]))
# ##    
#     '''5)***********************************SKIP GRAM MATCH************************'''
# #    
    print ("SKIP GRAM MATCH")
    text= eachtext.split(" ")
    print (text)
    textskipgram = list(skipgrams(text,2,1))
    print (textskipgram)
    
    hypothesis = eachhyp.split(" ")
    hypskipgram = list(skipgrams(hypothesis,2,1))
    print (hypskipgram)
    
    for sg in textskipgram:
        if sg in hypskipgram:
            skgram_match +=1
    
    skipgrammatch = skgram_match/len(hypskipgram)
    print(skipgrammatch)
    tempscore.append(skipgrammatch)
    
# #    
    '''4)***********************************LENGTH FEATURES************************'''
    
    '''a)*******************|B-A|,|A&B|,(|B|-|A|)/|A|,(|A|-|B|)/|B|,|A&B|/|B|**************'''
    tlist = eachtext.split()
    hlist = eachhyp.split()
    hlen = len(hlist)
    tlen = len(tlist)
    print(hlen)
    print(tlen)
    
    len1 = abs(len(hlist)-len(tlist))
    print("len1:"+str(len1))
    
    len2 = abs(hlen & tlen)
    print("len2:"+ str(len2))

    len3 = (abs(hlen) - abs(tlen))/abs(tlen)
    print("len3:"+ str(len3))

    len4 = (abs(tlen) - abs(hlen))/abs(hlen)
    print ("len4:"+ str(len4))

    len5 = abs(tlen & hlen)/abs(hlen)
    print("len5"+ str(len5))
    # tempscore.append (abs(len1))
    # tempscore.append (abs(len2))
    # tempscore.append (abs(len3))
    # tempscore.append (abs(len4))
    # tempscore.append (abs(len5))
    
    '''6)**********************************BLEU SCORE AND METEOR SCORE************************'''
    
    
    bleu_score = sentence_bleu( [eachtext.split()], eachhyp.split(),weights=(0.5,0.5))
    print("BLEU SCORE")
    print(bleu_score)
    tempscore.append(bleu_score)
#
    
    
    '''
    ======================Vector based Similarity===============================================
    '''
    
    '''1)***********************************WORD EMBEDDING COSINE************************'''
    
    print ("VECTOR BASED COSINE")
    
    textvectorlist = wv.get_sum_vector(wvmodel,eachtext)
    hypvectorlist = wv.get_sum_vector(wvmodel,eachhyp)
    
    if (len(hypvectorlist) !=0 and len(textvectorlist)!=0):
        sim = cosine_similarity(textvectorlist.reshape(1,-1),hypvectorlist.reshape(1,-1))
    else:
        sim = 0
        
    print (textvectorlist)
    print (hypvectorlist)
    print (sim)
    tempscore.append(sim[0][0])
    
    #tempscore.append(lasim[count][0][0])
    #count = count +1
       
    '''2)******************************TF-IDF*************************'''
    
    print ("VECTOR BASED TFIDF")
    from sklearn.feature_extraction.text import TfidfVectorizer
    # Transform each text into a vector of word counts
    vectorizer = TfidfVectorizer()
    #textvectorlist = vectorizer.fit_transform(eachtext)
    #hypvectorlist = vectorizer.fit_transform(eachhyp)
    d = [eachtext,eachhyp]    
#    tfidf = vectorizer.fit_transform(d1)
    
    tfidf_representation = tfidf(d)
#    our_tfidf_comparisons = []
#    for count_0, doc_0 in enumerate(tfidf_representation):
#        for count_1, doc_1 in enumerate(tfidf_representation):
#            our_tfidf_comparisons.append((cosine_similarity1(doc_0, doc_1), count_0, count_1))
#           
    tfidf_cossim= cosine_similarity([tfidf_representation[0]], [tfidf_representation[1]])
    simscore = tfidf_cossim[0][0]
    print ("TFIDF score")
    print (simscore)
    tempscore.append(simscore)
    
   
#    
    '''=======================SET BASED MEASURES==========================='''
    '''**********************DICE, JACCARD, COSINE, HARMONIC**************'''
    '''*****************************DICE SIMILARITY**************************'''
    '''Dice sim = 2|A&B|/(|A|+|B|)'''
    sdice = textdistance.sorensen_dice.normalized_similarity(eachtext, eachhyp)
    print("Dice")
    print(sdice)
#    hamng = textdistance.hamming.normalized_similarity(eachtext,eachhyp)
    cosne = textdistance.cosine.normalized_similarity(eachtext,eachhyp)
    print("cosine")
    print(cosne)

    lev = textdistance.levenshtein.normalized_similarity(eachtext,eachhyp)
    print("lev")
    print(lev)
#    mong = textdistance.monge_elkan.normalized_similarity(eachtext,eachhyp)
    needlew = textdistance.needleman_wunsch.normalized_similarity(eachtext,eachhyp)
    print("needlew")
    print(needlew)
    smithw = textdistance.smith_waterman.normalized_similarity(eachtext,eachhyp)
    print("smithw")
    print(smithw)
    jarosim = textdistance.jaro.normalized_similarity(eachtext,eachhyp)
    print("jaro")
    print(jarosim)
#    overlapsim = textdistance.overlap.normalized_similarity(eachtext,eachhyp)
    jaccsim = textdistance.jaccard.normalized_similarity(eachtext,eachhyp)
    print("jacca")
    print(jaccsim)
#    
    tempscore.append(sdice)
#    tempscore.append(hamng)
    tempscore.append(cosne)
    tempscore.append(lev)
#    tempscore.append(mong)
    tempscore.append(needlew)
    tempscore.append(smithw)
    tempscore.append(jarosim)
#    tempscore.append(overlapsim)
    tempscore.append(jaccsim)



    #avgsimscore = (sdice+cosne+mong+overlapsim+jaccsim)/10
    
    #tempscore.append(avgsimscore)
    
    
    '''**********************************************************'''
    
    scores[count] = tempscore
       
    count = count +1
    for e in scores:
        tmp=0
        for y in scores[e]:
            #print (y)
            tmp += y
        scoresum[e] = tmp
        #print (scoresum[e])
    
    f.write(str(count))
    f.write(" ")
    f.write(str(tempscore))
    f.write("\n")
#    f.write(str(scoresavg))
#    f.write("\n")
f.close() 

from sklearn import metrics

sc1 = list(scores.values())


X_train, X_test, y_train, y_test = train_test_split(sc1, output_Y, test_size=0.2,random_state=109)

from sklearn.metrics import classification_report
'''=====================Logistic regression==============================================='''
from sklearn.linear_model import LogisticRegression
#LR = LogisticRegression(random_state=0, solver='lbfgs', multi_class='ovr').fit(X_train, y_train) #binary
#LR = LogisticRegression(random_state=0, solver='liblinear', class_weight='balanced').fit(X_train,y_train)
LR = LogisticRegression(random_state=0, solver='lbfgs', multi_class='multinomial').fit(X_train, y_train) #multiclass
LRpred = LR.predict(X_test)
print ("Logistic Regression")
# Model Accuracy: how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, LRpred))

# Model Precision: what percentage of positive tuples are labeled as such?
print("Precision:",metrics.precision_score(y_test, LRpred,average = 'weighted'))

# Model Recall: what percentage of positive tuples are labelled as such?
print("Recall:",metrics.recall_score(y_test, LRpred,average = 'weighted'))

print(classification_report(y_test,LRpred))

'''=====================SVM=============================================================='''
#from sklearn.svm import SVC
from sklearn import svm
from sklearn.model_selection import GridSearchCV
#from sklearn.multiclass import OneVsRestClassifier

#clf = SVC(kernel='linear')  #binary
#clf.fit(X_train, y_train)
#clf = SVC(decision_function_shape="ovr").fit(X_train, y_train) #muliclass
#--y_pred = clf.predict(X_test)
#classif = OneVsRestClassifier(estimator=SVC(random_state=0))
#y_pred=classif.fit(X_train, y_train).predict(X_test)
parameters = {'kernel':('ovr', 'rbf'), 'C':[1, 10],'gamma': [1, 0.1, 0.01, 0.001, 0.0001]}
svc = svm.SVC()
clf = GridSearchCV(svc, parameters,cv=4)
clf.fit(X_train,y_train)
y_pred = clf.predict(X_test)

print ("SVM")
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
print("Precision:",metrics.precision_score(y_test, y_pred,average = 'weighted'))
print("Recall:",metrics.recall_score(y_test, y_pred,average = 'weighted'))
print(classification_report(y_test,y_pred))


# print best parameter after tuning 
print(clf.best_params_)
  
# print how our model looks after hyper-parameter tuning 
print(clf.best_estimator_) 


'''=========================================Random Forests==================================='''
from sklearn.ensemble import RandomForestClassifier
RF = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=0)
RF.fit(X_train, y_train)
#RF = RandomForestClassifier(n_estimators=10, max_depth=3, random_state=0).fit(X_train, y_train)
RFpred = RF.predict(X_test)


print ("Random Forest")
print("Accuracy:",metrics.accuracy_score(y_test, RFpred))
print("Precision:",metrics.precision_score(y_test, RFpred,average = 'weighted'))
print("Recall:",metrics.recall_score(y_test, RFpred,average = 'weighted'))
print(classification_report(y_test,RFpred))


'''==============================Neural Network================================================='''
from sklearn.neural_network import MLPClassifier
#NN = MLPClassifier(solver='lbfgs', alpha=1e-5, hidden_layer_sizes=(5, 2), random_state=1)
#NN.fit(X_train, y_train)
NN = MLPClassifier(solver='adam', alpha=1e-5, hidden_layer_sizes=(5, 3), random_state=1).fit(X_train, y_train)
NNpred = NN.predict(X_test)
print ("Neural network")
print("Accuracy:",metrics.accuracy_score(y_test, NNpred))
print("Precision:",metrics.precision_score(y_test, NNpred,average = 'micro'))
print("Recall:",metrics.recall_score(y_test, NNpred,average = 'micro'))
print(classification_report(y_test,NNpred))

'''===============================OTHERS======================================'''
from sklearn.neighbors import KNeighborsClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

from sklearn.naive_bayes import MultinomialNB
mnb = MultinomialNB()
mnb.fit(X_train,y_train)
mnbpred = mnb.predict(X_test)
print ("MNB")
print ("Accuracy:", metrics.accuracy_score(y_test,mnbpred))
print ("Precision:", metrics.precision_score(y_test, mnbpred,average = 'micro'))
print ("Recall:", metrics.recall_score(y_test, mnbpred,average = 'micro'))
print (classification_report(y_test,mnbpred))



knn = KNeighborsClassifier(3)
knn.fit(X_train,y_train)
KNNpred = knn.predict(X_test)
print ("KNN")
print("Accuracy:",metrics.accuracy_score(y_test, KNNpred))
print("Precision:",metrics.precision_score(y_test, KNNpred,average = 'micro'))
print("Recall:",metrics.recall_score(y_test, KNNpred,average = 'micro'))
print(classification_report(y_test,KNNpred))

DTC = DecisionTreeClassifier(max_depth=4)
DTC.fit(X_train,y_train)
DTCpred = DTC.predict(X_test)
print ("Decision Tree Classiifer")
print("Accuracy:",metrics.accuracy_score(y_test, DTCpred))
print("Precision:",metrics.precision_score(y_test, DTCpred,average = 'micro'))
print("Recall:",metrics.recall_score(y_test, DTCpred,average = 'micro'))
print(classification_report(y_test,DTCpred))


ABC = AdaBoostClassifier()
ABC.fit(X_train,y_train)
ABCpred = ABC.predict(X_test)
print ("AdaBoost")
print("Accuracy:",metrics.accuracy_score(y_test, ABCpred))
print("Precision:",metrics.precision_score(y_test, ABCpred,average = 'micro'))
print("Recall:",metrics.recall_score(y_test, ABCpred,average = 'micro'))
print(classification_report(y_test,ABCpred))

GNB = GaussianNB()
GNB.fit(X_train,y_train)
GNBpred = GNB.predict(X_test)
print ("GNB")
print("Accuracy:",metrics.accuracy_score(y_test, GNBpred))
print("Precision:",metrics.precision_score(y_test, GNBpred,average = 'micro'))
print("Recall:",metrics.recall_score(y_test, GNBpred,average = 'micro'))

'''

'''EVALUATION METRICS'''   
'''
output_Y = [int(i) for i in output_Y] 
predictedclass = [int(predictedclass[i]) for i in predictedclass] 
precision = precision_score(output_Y, predictedclass, average='binary')
print('Precision: %.3f' % precision)
recall = recall_score(output_Y, predictedclass, average='binary')
print('Recall: %.3f' % recall)
score = f1_score(output_Y, predictedclass,  average='binary')
print('F-Measure: %.3f' % score)




from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# print accuracy
print("Accuracy: ", accuracy_score(output_Y, predictedclass))

# print precision, recall, F1-score per each class/tag
print(classification_report(output_Y, predictedclass))

# print confusion matrix, check documentation for sorting rows/columns
print(confusion_matrix(output_Y, predictedclass))
'''
