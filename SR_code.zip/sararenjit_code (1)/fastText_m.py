#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 22 05:19:28 2020
fastText word vectors based multiclass classification
@author: sara
"""

import numpy as np
from matplotlib import pyplot
import pandas as pd
from gensim.models import KeyedVectors
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import Dense, Input, LSTM, Embedding, Dropout, Activation
from keras.layers.merge import concatenate,subtract, multiply
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.callbacks import EarlyStopping
from keras.utils import to_categorical
from sklearn import preprocessing
import gensim


MAX_SEQUENCE_LENGTH = 30
MAX_NB_WORDS = 200000
EMBEDDING_DIM = 300
VALIDATION_SPLIT = 0.1
rate_drop_lstm = 0.15 + np.random.rand() * 0.25
rate_drop_dense = 0.15 + np.random.rand() * 0.25

def text_to_tokens(text):
    return text.lower()

def get_label_index_mapping():
    return {"neutral": 0, "contradiction": 1, "entailment": 2}
    
def create_embedding_matrix(word_index):
    nb_words = min(MAX_NB_WORDS, len(word_index))+1    
    word2vec = gensim.models.KeyedVectors.load_word2vec_format('wiki.ml.vec')
    embedding_matrix = np.zeros((nb_words, EMBEDDING_DIM))
    for word, i in word_index.items():
        if word in word2vec.vocab:
            embedding_matrix[i] = word2vec.word_vec(word)
    return embedding_matrix

def load_data():
    import xlrd 
    loc = ("data.xlsx") 
    text =[]
    hypothesis = []
    label =[]
    
    wb = xlrd.open_workbook(loc) 
    sheet = wb.sheet_by_name('Data') 
    print(sheet.cell_value(0, 0) )
      
    for i in range(1,sheet.nrows):
        text.append(sheet.cell_value(i,0))
        hypothesis.append(sheet.cell_value(i,1))
        label.append(sheet.cell_value(i,2))
        
    sentence1 = text
    sentence2 = hypothesis
    
    label_encoder = preprocessing.LabelEncoder()
    y = label_encoder.fit_transform(label)
    
    tokenizer = Tokenizer(num_words=MAX_NB_WORDS)
    tokenizer.fit_on_texts(sentence1 + sentence2)
    sequences1 = tokenizer.texts_to_sequences(sentence1)
    sequences2 = tokenizer.texts_to_sequences(sentence2)
    X1 = pad_sequences(sequences1, maxlen=MAX_SEQUENCE_LENGTH)
    X2 = pad_sequences(sequences2, maxlen=MAX_SEQUENCE_LENGTH)

    train_index = 5600
    test_index = 7000

    X1_train = X1[:train_index]
    X2_train = X2[:train_index]
    y_train = y[:train_index]
    
    X1_valid = X1[train_index:test_index]
    X2_valid = X2[train_index:test_index]
    y_valid = y[train_index:test_index]
    
    X1_test = X1[test_index:]
    X2_test = X2[test_index:]
    y_test = y[test_index:]    
    
    return (X1_train, X2_train, y_train), (X1_valid, X2_valid, y_valid),(X1_test, X2_test, y_test), tokenizer

def StaticEmbedding(embedding_matrix):
    input_dim, output_dim = embedding_matrix.shape
    return Embedding(input_dim,
            output_dim,
            weights=[embedding_matrix],
            input_length=MAX_SEQUENCE_LENGTH,
            trainable=False)
    
def entail(feat1, feat2, num_dense=300):
    s = subtract([feat1,feat2])
    p = multiply([feat1,feat2])
    x = concatenate([feat1, feat2,p,s])
    x = Dense(1200, activation="relu")(x)
    x = Dropout(rate_drop_dense)(x)
    x = BatchNormalization()(x)
    x = Dense(600, activation="relu")(x)    
    x = Dropout(rate_drop_dense)(x)
    x = BatchNormalization()(x)
    return x

def build_model(output_dim, embedding_matrix, num_lstm=300):
    sequence1_input = Input(shape=(MAX_SEQUENCE_LENGTH,), dtype='int32')
    sequence2_input = Input(shape=(MAX_SEQUENCE_LENGTH,), dtype='int32')
   
    # Embedding
    embed = StaticEmbedding(embedding_matrix)
    embedded_sequences1 = embed(sequence1_input)
    embedded_sequences2 = embed(sequence2_input)
    
    # Encoding
    encode = LSTM(num_lstm, dropout=rate_drop_lstm, recurrent_dropout=rate_drop_lstm)
    feat1 = encode(embedded_sequences1)
    feat2 = encode(embedded_sequences2)
   
    x = entail(feat1, feat2)
    preds = Dense(output_dim, activation='softmax')(x)
    model = Model(inputs=[sequence1_input, sequence2_input], outputs=preds)
    return model

    
if __name__ == "__main__":
    num_class = 3
    (X1_train, X2_train, y_train), (X1_valid, X2_valid, y_valid), (X1_test, X2_test, y_test),tokenizer = load_data()
    Y_train, Y_valid, Y_test = to_categorical(y_train, num_class), to_categorical(y_valid, num_class), to_categorical(y_test, num_class)
    embedding_matrix = create_embedding_matrix(tokenizer.word_index) 
    model = build_model(output_dim=num_class, embedding_matrix=embedding_matrix) 
    model.compile(loss='categorical_crossentropy', optimizer='nadam', metrics=['acc'])
    model.summary()
    early_stopping = EarlyStopping(monitor='val_loss', patience=5)
    hist = model.fit([X1_train, X2_train], Y_train, validation_data=([X1_valid, X2_valid], Y_valid),epochs=200, batch_size=2048, shuffle=True,callbacks=[early_stopping])
    scores = model.evaluate([X1_test,X2_test],Y_test)
    print ("Scores:", scores)
    trainscore = model.evaluate([X1_train,X2_train],Y_train)
    
    pyplot.plot(hist.history['loss'], label='train')
    pyplot.plot(hist.history['val_loss'], label='validation')
    pyplot.ylabel('loss')
    pyplot.xlabel('epoch')
    pyplot.title('model loss')
    pyplot.legend()
    pyplot.show()


    pyplot.plot(hist.history['acc'],label='train')
    pyplot.plot(hist.history['val_acc'], label='validation')
    pyplot.title('model accuracy')
    pyplot.ylabel('accuracy')
    pyplot.xlabel('epoch')
    pyplot.legend()
    pyplot.show()

    y_prob = model.predict([X1_test,X2_test])
    y_pred = y_prob.argmax(axis=-1)

    #Evaluation

    y_test_output_Y_onehot = np.argmax(Y_test, axis=1)
    
    from sklearn.metrics import classification_report,accuracy_score
    target_names = ['contradiction','entailment','neutral']
    print(classification_report(y_test_output_Y_onehot, y_pred, target_names=target_names))
    print (accuracy_score(y_test_output_Y_onehot, y_pred))
    
    from sklearn.metrics import matthews_corrcoef
    matthews_corrcoef(y_test_output_Y_onehot, y_pred)

    from sklearn.metrics import log_loss
    log_loss(y_test_output_Y_onehot, y_prob)
    
    from sklearn.metrics import roc_curve, auc
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(3):
        fpr[i], tpr[i], _ = roc_curve(Y_test[:,i], y_prob[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    
    pyplot.figure()
    pyplot.plot(fpr[0], tpr[0], label='ROC curve (area = %0.2f)Contradiction' % roc_auc[0], color='red')
    pyplot.plot(fpr[1], tpr[1], label='ROC curve (area = %0.2f)Entailment' % roc_auc[1] , color='blue' )
    pyplot.plot(fpr[2], tpr[2], label='ROC curve (area = %0.2f)Neutral' % roc_auc[2] , color='green' )
    pyplot.plot([0, 1], [0, 1], 'k--')
    pyplot.xlim([0.0, 1.0])
    pyplot.ylim([0.0, 1.05])
    pyplot.xlabel('False Positive Rate')
    pyplot.ylabel('True Positive Rate')
       
    pyplot.legend(loc="lower right")
    pyplot.show()  

